package com.example.pmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pmobile.data.AppDbProvider;
import com.example.pmobile.data.User;
import com.example.pmobile.data.UserDao;

public class RegisterActivity extends AppCompatActivity {

    private EditText etNama;
    private EditText etNim;
    private EditText etPassword;
    private Button btn_Reg;


    private User makeUser(){
        User us = new User();
        us.nama = this.etNama.getText().toString().trim();
        us.nim = this.etNim.getText().toString().trim();
        us.password = this.etPassword.getText().toString().trim();
        return us;
    }

    private boolean auth(){
        String currentNim = this.etNim.getText().toString().trim();
        String currentPassword = this.etPassword.getText().toString().trim();
        String currentNama = this.etNama.getText().toString().trim();

        if (currentNama.isEmpty() && currentNim.isEmpty() && currentPassword.isEmpty())
            Toast.makeText(this, "Nama, NIM & Password Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentNama.isEmpty() && currentPassword.isEmpty())
            Toast.makeText(this, "Nama & Password Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentNim.isEmpty() && currentNama.isEmpty())
            Toast.makeText(this, "Nama & NIM Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentNim.isEmpty() && currentPassword.isEmpty())
            Toast.makeText(this, "NIM & Password Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentNim.isEmpty())
            Toast.makeText(this, "NIM Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentPassword.isEmpty())
            Toast.makeText(this, "Password Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else if (currentNama.isEmpty())
            Toast.makeText(this, "Nama Tidak Boleh Kosong!", Toast.LENGTH_SHORT).show();
        else {
            UserDao user = AppDbProvider.getInstance(this).userDao();
            User currentUserData = user.findByNim(currentNim);
            if (currentUserData != null)
                Toast.makeText(this, "Anda Sudah Terdaftar!", Toast.LENGTH_SHORT).show();
            else
                return true;
        }
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        this.btn_Reg = this.findViewById(R.id.btn_reg);
        this.etNama = this.findViewById(R.id.et_nama);
        this.etNim = this.findViewById(R.id.et_nim);
        this.etPassword = this.findViewById(R.id.et_password);

        this.btn_Reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = auth();
                if (valid){
                    UserDao user = AppDbProvider.getInstance(getApplicationContext()).userDao();
                    user.insertAll(makeUser());
                    Toast.makeText(RegisterActivity.this, "Registrasi Berhasil!",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
}