package com.example.pmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.pmobile.data.AppDbProvider;
import com.example.pmobile.data.User;
import com.example.pmobile.data.UserDao;

public class LoginActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;

    private static final String KEEP_LOGIN_KEY = "key_keep_login";

    private EditText etNim;
    private EditText etPassword;
    private Button btnLogin;
    private Button btnReg;
    private User currentUser;

    private boolean auth(){
        String currentNim = this.etNim.getText().toString();
        String currentPassword = this.etPassword.getText().toString();

        UserDao user = AppDbProvider.getInstance(this).userDao();
        currentUser = user.findByNimAndPassword(currentNim,currentPassword);

        return currentUser!=null?true:false;
    }

    private void makeAutoLogin(){
        SharedPreferences.Editor editor = this.sharedPreferences.edit();
        editor.putBoolean(KEEP_LOGIN_KEY, true);
        editor.apply();
    }

    private void autoLogin(){
        boolean auto = this.sharedPreferences.getBoolean(KEEP_LOGIN_KEY, false);
        if (auto){
            Intent i = new Intent(LoginActivity.this, Home.class);
            startActivity(i);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnLogin = findViewById(R.id.btn_login);
        btnReg = findViewById(R.id.btn_reg);
        etNim = findViewById(R.id.et_nim);
        etPassword = findViewById(R.id.et_password);
        sharedPreferences = this.getSharedPreferences("sharedprefs-2000018246", Context.MODE_PRIVATE);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = auth();
                if (valid){
                    Intent i = new Intent(LoginActivity.this, Home.class);
                    startActivity(i);
                    makeAutoLogin();
                    finish();
                }
                else{
                    Toast.makeText(LoginActivity.this, "Akun Tidak Valid!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });
        autoLogin();
    }
}